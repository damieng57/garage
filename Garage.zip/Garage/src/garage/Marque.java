package garage;

enum Marque {
    RENO , PIGEOT , TROEN ;
}
