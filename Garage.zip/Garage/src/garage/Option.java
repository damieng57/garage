package garage;

public interface Option {
    public double getPrix();
}
